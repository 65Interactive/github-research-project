<?php
	ini_set('display_errors',1);
	error_reporting(E_ALL);
	require_once('includes/init.php');
	

?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Multiple Returns</title>
</head>
<body>
	

</body>
</html>